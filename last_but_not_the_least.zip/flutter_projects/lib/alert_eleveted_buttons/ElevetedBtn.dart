import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class ElevetedBtnApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('ElevatedButton Example'),
        ),
        body: Center(
          child: ElevatedBtn(),
        ),
      ),
    );
  }
}

class ElevatedBtn extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 300,
      height: 100,
      child: ElevatedButton(
        onPressed: () {
          _showAlertDialog(context);
          print('Clicked');
        },
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.zero,
        ),
        child: Ink(
          decoration: BoxDecoration(
              gradient:
              LinearGradient(colors: [Colors.blue, Colors.purple]),
              borderRadius: BorderRadius.circular(50.0)),
          child: Center(
            child: Text(
              'Press Me',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18.0,
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showAlertDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Awesome Alert'),
          backgroundColor: Colors.blueGrey,
          content: Text('This is a cool Alert Dialog with a custom background color.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
