import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ElevatedBtn2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Two Elevated Buttons Example'),
        ),
        body: Center(
            child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Colors.blue, Colors.purple]),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Welecome to Flutter UI',
                style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange),
                      onPressed: () {
                        // Add your button click logic here
                        print('Button 1 pressed!');
                      },
                      child: Center(
                        child: Container(
                          height: 80,
                          width: 200,
                          child: Center(
                            child: Text(
                              'Button 1',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      )),
                  ElevatedButton(
                      onPressed: () {
                        // Add your button click logic here
                        print('Button 2 pressed!');
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green),
                      child: Center(
                        child: Container(
                          height: 80,
                          width: 200,
                          child: Center(
                            child: Text(
                              'Button 2',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      )),
                ],
              ),
            ],
          ),
        )),
      ),
    );
  }
}
