import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class ShowingInAlertApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('ElevatedButton Example'),
        ),
        body: Center(
          child: ShowingInAlert(),
        ),
      ),
    );
  }
}
class ShowingInAlert extends StatelessWidget {
  String inputText="";
  @override
  Widget build(BuildContext context) {
    return Center(
        child:Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                onChanged: (text) {
                  inputText=text;
                },
                controller: TextEditingController(),
                decoration: InputDecoration(
                  labelText: 'Enter text',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  String enteredText = "No text is found";
                  if(inputText.length>=1){
                    enteredText = inputText;
                  }
                  _showAlertDialog(context, enteredText);
                },
                child: Text('Show Alert'),
              ),
            ],
          ),
        )
    );
  }

  void _showAlertDialog(BuildContext context, String enteredText) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Entered Text'),
          content: Text(enteredText),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}