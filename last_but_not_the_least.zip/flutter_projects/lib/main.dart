import 'package:flutter/material.dart';
import 'package:flutter_projects/alert_eleveted_buttons/ElevatedBtin2.dart';
import 'package:flutter_projects/alert_eleveted_buttons/ElevetedBtn.dart';
import 'package:flutter_projects/lists/Example2.dart';
import 'package:flutter_projects/lists/Example3GridWithImage.dart';
import 'package:flutter_projects/lists/Lists.dart';
import 'package:flutter_projects/text_fields/ShowingInAlert.dart';
import 'package:flutter_projects/text_fields/password_text_field.dart';

void main() {
  //runApp(Example2());
  //runApp(Lists());
  //runApp(Example3GridWithImage());
  //runApp(ElevetedBtnApp());
  //runApp(ElevatedBtn2());
  //runApp(ShowingInAlertApp());
  runApp(PasswordTextFieldApp());
}
