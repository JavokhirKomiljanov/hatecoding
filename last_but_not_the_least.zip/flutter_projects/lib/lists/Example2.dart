import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Example2 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
   return MaterialApp(
     home: Scaffold(
       appBar: AppBar(title: Text('Example 2'),),
       body: Container(
         margin: EdgeInsets.symmetric(horizontal: 10.0,vertical: 10.0),
         child: ListWithImage(),
       ),
     ),
   );
  }
}
class ListWithImage extends StatelessWidget{
  final List<String> itemTexts = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
  ];
  @override
  Widget build(BuildContext context) {
    
    return ListView.builder(itemCount: itemTexts.length,
    itemBuilder: (context,int index){
      return Card(
        margin: EdgeInsets.all(8.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0)
        ),
        child: Column(
          children: [
            Container(
              height: 400,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(15.0),
                  topRight: Radius.circular(15.0)
                ),
                image: DecorationImage(
                  image: AssetImage('images/no_face_image.png'),
                  fit: BoxFit.fitHeight,

                )
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Text(
                  itemTexts[index],
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold
                  ),
                ),
              ),
            )
          ],
        ),
      );
    });
  }

}