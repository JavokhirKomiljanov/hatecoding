import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Lists extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Example 1'),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //horizontal
              Container(
                margin: EdgeInsets.symmetric(vertical: 10.0),
                height: 300.0,
                child: HorizontalListView(),
              ),
              // Vertical List
              Container(
                margin: EdgeInsets.symmetric(vertical: 10.0),
                height: 300.0,
                child: VerticalListView(),
                color: Colors.blue,
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 10.0),
                height: 400.0,
                child: GridViewExample(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HorizontalListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      scrollDirection: Axis.horizontal,
      children: List.generate(10, (index) {
        return Container(
          width: 100.0,
          color: Colors.blue,
          margin: EdgeInsets.all(8.0),
          child: Center(
            child: Text(
              'Item $index',
              style: TextStyle(color: Colors.white),
            ),
          ),
        );
      }),
    );
  }
}

class VerticalListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      scrollDirection: Axis.vertical,
      itemCount: 20,
      itemBuilder: (context, index) {
        return ListTile(
          title: Center(
            child: Text(
              'Item $index',
              style: TextStyle(color: Colors.white),
            ),
          ),
        );
      },
    );
  }
}

class GridViewExample extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 8.0,
        mainAxisSpacing: 8.0,
      ),
      itemCount: 12,
      itemBuilder: (context, index) {
        return Container(
          color: Colors.green,
          child: Center(
            child: Text(
              'Grid Item $index',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        );
      },
    );
  }
}
