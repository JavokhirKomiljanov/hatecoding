import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SomeGradus extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('My Flutter App',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),
          centerTitle: true,
          backgroundColor: Colors.deepPurple,
        ),
        body: Center(
            child: Transform.rotate(angle: 15 * 3.14159 / 180,
            child: Container(
              width: 200.0,
              height: 200.0,
              decoration: BoxDecoration(
                  color: Colors.blue,
                  boxShadow: [BoxShadow(
                      color: Colors.grey,
                      offset: Offset(0,4),
                      blurRadius: 6.0
                  )],
                  borderRadius: BorderRadius.circular(15.0)
              ),
              child: Center(
                child: Text('Hello Flutter!',style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                ),),
              ),
            ),)
        ),
      ),
    );
  }

}