import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MyFlutterApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('My Flutter App',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),
          centerTitle: true,
          backgroundColor: Colors.indigoAccent,
        ),
        body: Center(
          child: Text('Hello, Flutter!',
            style: TextStyle(fontSize: 50.0,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.underline,
            decorationColor: Colors.red,
            decorationThickness: 2.0,
            color: Colors.blueAccent),
          ),
        ),
      ),
    );
  }

}