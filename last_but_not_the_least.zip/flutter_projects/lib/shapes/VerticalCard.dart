import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class VerticalCard extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('My Flutter App',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),
          centerTitle: true,
          backgroundColor: Colors.deepPurple,
        ),
        body: Center(
          child: Container(
            width: 200.0,
            height: 200.0,
            decoration: BoxDecoration(
              color: Colors.teal,
                boxShadow: [BoxShadow(
                color: Colors.grey,
                  offset: Offset(0,4),
                  blurRadius: 6.0
            )],
              borderRadius: BorderRadius.circular(15.0)
            ),
            child: Center(
              child: Text('Flutter Rocks!',style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),),
            ),
          )
        ),
      ),
    );
  }

}