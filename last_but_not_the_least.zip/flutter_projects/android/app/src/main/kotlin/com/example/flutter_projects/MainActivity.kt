package com.example.flutter_projects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
